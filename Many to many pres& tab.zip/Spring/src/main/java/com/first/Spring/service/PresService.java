package com.first.Spring.service;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.first.Spring.entity.Prescription;
import com.first.Spring.entity.Tablet;
import com.first.Spring.repo.PresRepository;
import com.first.Spring.repo.TabletRepository;

@Service
public class PresService {

	@Autowired
	PresRepository repo;
	
	@Autowired
	TabletRepository Trepo;

	public Prescription add(Prescription pres) {
		Prescription id=repo.findByUserid(pres.getUserid());
		
		if(id==null) {
		List<Tablet> list=pres.getTablets();
		List<Tablet> flist=new ArrayList<>();
	    for(Tablet e:list) {
	    Tablet t=Trepo.save(e);
	    	flist.add(t);
	    }
	    pres.setTablets(flist);
		return repo.save(pres);
		}
	   else {
	      return null;
	  }}

//	public Tablet print(long userid) {
//		Prescription tablet=repo.findByUserid(userid);
//		tablet.getTablets();
//		return null;
//	}

	public List<Tablet> prin(long userid) {
		Prescription p=repo.findByUserid(userid);
		List<Tablet> tab=p.getTablets();
		return tab;
	}
	

	//public Tablet 
//	public Prescription present(long presid, int tabid) {
//		Prescription p=repo.findByPresid(presid);
//		Tablet t=Trepo.findByTabid(tabid);
//		List<Tablet> array=p.getTablets();
//	    array.add(t);
//	    p.setTablets(array);
//	    return repo.save(p);
//	}
//
//	public List<String> print(long userid) {
//		Prescription p=repo.findByUserid(userid);
//		List<Tablet> tab=p.getTablets();
//		List<String> name=new ArrayList<>();
//		for(Tablet e:tab) {
//			name.add(e.getTabletname());
//		}
//		return name;
//	}
	
	

}
