package com.first.Spring.controller;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.service.annotation.PutExchange;

import com.first.Spring.entity.Prescription;
import com.first.Spring.entity.Tablet;
import com.first.Spring.service.PresService;

@RestController

public class PresController {

	@Autowired
	PresService ser;
	
	@PostMapping("/insert")
	public Prescription add(@RequestBody Prescription pres) {
		return ser.add(pres);
	}
	@PutMapping("/print/{userid}")
	public List<Tablet> prin(@PathVariable long userid) {
		return ser.prin(userid);
	}
//	@PostMapping("/tablet")
//	public Tablet adds(@RequestBody Tablet tab) {
//		return ser.adds(tab);
//	}
	//@PutMapping("/name/{userid}")
	//public Tablet 
//	@PutMapping("{presid}/add/{tabid}")
//	public Prescription present(@PathVariable long presid, @PathVariable int tabid) {
//		return ser.present(presid,tabid);
//	}
//	@GetMapping("get/{userid}")
//	public List<String> print(@PathVariable long userid){
//		return ser.print(userid);
//	}
	
}
