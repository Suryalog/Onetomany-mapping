package com.first.Spring.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.first.Spring.entity.Userentity;

@Repository
public interface UserRepo extends JpaRepository<Userentity, Long> {

	//@Query("select a from UserRepo a where a.age=44")
	public Userentity findByAge(int a);
	
	
}