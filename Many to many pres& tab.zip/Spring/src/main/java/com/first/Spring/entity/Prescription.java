package com.first.Spring.entity;

import java.util.List;

import org.hibernate.annotations.ManyToAny;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.JoinTable;
import jakarta.persistence.ManyToMany;

@Entity
public class Prescription {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private long presid;
	private long userid;
	private long docid;
	
	public long getDocid() {
		return docid;
	}
	public void setDocid(long docid) {
		this.docid = docid;
	}
	@ManyToMany(cascade = CascadeType.ALL)
	@JoinTable(name ="pres_tab", joinColumns= {
			@JoinColumn(name="presid")},inverseJoinColumns = {
	        @JoinColumn(name="tabid")
	})
	private List<Tablet> tablets;
	public long getPresid() {
		return presid;
	}
	public void setPresid(long presid) {
		this.presid = presid;
	}
	public long getUserid() {
		return userid;
	}
	public void setUserid(long userid) {
		this.userid = userid;
	}
	public List<Tablet> getTablets() {
		return tablets;
	}
	public void setTablets(List<Tablet> tablets) {
		this.tablets = tablets;
	}
	
	

}
