package com.first.Spring.repo;

import org.springframework.data.jpa.repository.JpaRepository;

import com.first.Spring.entity.Tablet;

public interface TabletRepository extends JpaRepository<Tablet, Integer>{

	public Tablet findByTabid(int a);
}
