package com.first.Spring.entity;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
@Entity
public class Userentity {
    
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
    private Long uerid;
	//@Column(name="nam",nullable=false)
    private String name;
    private String passwored;
    private int age;
	public Long getUerid() {
		return uerid;
	}
	public void setUerid(Long uerid) {
		this.uerid = uerid;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPasswored() {
		return passwored;
	}
	public void setPasswored(String passwored) {
		this.passwored = passwored;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
    
    
}
