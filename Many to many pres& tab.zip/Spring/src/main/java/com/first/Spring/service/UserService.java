package com.first.Spring.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.first.Spring.entity.Userentity;
import com.first.Spring.repo.UserRepo;

@Service
public class UserService {

	
	
	
	@Autowired
	public UserRepo repo;



public void registeruser(Userentity user)
{
	repo.save(user);
	

}
}
