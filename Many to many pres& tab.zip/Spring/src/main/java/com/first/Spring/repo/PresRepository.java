package com.first.Spring.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.first.Spring.entity.Prescription;

@Repository
public interface PresRepository extends JpaRepository<Prescription, Long>{
    Prescription findByPresid(Long a);
    Prescription findByUserid(Long a);
}
