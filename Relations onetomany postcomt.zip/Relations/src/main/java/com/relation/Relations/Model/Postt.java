package com.relation.Relations.Model;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.FetchType;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;

@Entity
public class Postt{
	
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
   private int id;
   private String name;
   
   @OneToMany( mappedBy = "postt",cascade = CascadeType.ALL)
   private List<Commentt>commentt;

   
   
public Postt(int id, String name, List<Commentt> commentt) {
	super();
	this.id = id;
	this.name = name;
	this.commentt = commentt;
}


public Postt() {
	super();
	// TODO Auto-generated constructor stub
}


public int getId() {
	return id;
}

public void setId(int id) {
	this.id = id;
}

public String getName() {
	return name;
}

public void setName(String name) {
	this.name = name;
}

public List<Commentt> getComment() {
	return commentt;
}

public void setComment(List<Commentt> commentt) {
	this.commentt = commentt;
}


@Override
public String toString() {
	return "Postt [id=" + id + ", name=" + name + ", commentt=" + commentt + "]";
}
   
//  public void add(Commentt com) {
//	  if(com!=null) {
//		  if(commentt==null) {
//			  commentt=new HashSet<>();
//		  }
//		  com.setPost(this);
//		  commentt.add(com);
//	  }
//  }
  
	

}
