package com.relation.Relations.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.relation.Relations.Model.Postt;
import com.relation.Relations.Service.PosttService;
import com.relation.Relations.Service.PosttService;

@RestController
public class Postcont {
	
	@Autowired
	PosttService ser;
	
	@PostMapping("/add")
	public String add(@RequestBody Postt pos) {
		return ser.add(pos);
	}
//	@GetMapping("/get")
//	public List<Postt> get(){
//		return ser.get();
//	}

}
