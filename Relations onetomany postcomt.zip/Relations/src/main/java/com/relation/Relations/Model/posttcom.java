package com.relation.Relations.Model;

import org.hibernate.annotations.Comment;
import org.springframework.stereotype.Component;

@Component
public class posttcom {
	

}
