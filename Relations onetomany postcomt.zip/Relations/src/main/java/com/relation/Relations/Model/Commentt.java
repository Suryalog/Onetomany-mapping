package com.relation.Relations.Model;

import org.hibernate.annotations.ManyToAny;

import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
@Entity
public class Commentt 
{

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private int id;
	private String text;
	
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name="post_id")
	private Postt postt;
	
	public Commentt(int id, String text, Postt postt) 
	{
		super();
		this.id = id;
		this.text = text;
		this.postt = postt;
	}
	
	

	public Commentt() 
	{
		super();
		// TODO Auto-generated constructor stub
	}



	public int getId() 
	{
		return id;
	}

	public void setId(int id) 
	{
		this.id = id;
	}

	public String getText() 
	{
		return text;
	}

	public void setText(String text) 
	{
		this.text = text;
	}

	public Postt getPost() 
	{
		return postt;
	}

	public void setPost(Postt postt) 
	{
		this.postt = postt;
	}
	
	
}
