package com.relation.Relations.Service;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.annotations.Comment;
import org.hibernate.mapping.Set;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.relation.Relations.Model.Commentt;
import com.relation.Relations.Model.Postt;
import com.relation.Relations.Repo.Commentrepo;
import com.relation.Relations.Repo.Posttrepo;
import com.relation.Relations.Repo.Posttrepo;

@Service
public class PosttService 
{

	@Autowired
	Posttrepo repo;
	
	@Autowired
	Commentrepo crepo;
	
	public String add(Postt pos) {
		// TODO Auto-generated method stub
		System.out.println(pos.toString());
		List<Commentt> li=pos.getComment();
		for(Commentt e:li) {
			System.out.println(e.getText());
		}
		Commentt c=new Commentt();
		List<Commentt> com=new ArrayList<>();
		for(Commentt e:li) {
			c.setText(e.getText());
			c.setPost(pos);
			com.add(c);
		}
		repo.save(pos);
		crepo.saveAll(com);
		return "added";
	
	}

//	public List<Postt> get() {
//		List<Postt> li=repo.findAll();
//		return li;
//	}

}
