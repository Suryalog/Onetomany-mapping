package com.relation.Relations.Repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.relation.Relations.Model.Commentt;

@Repository
public interface Commentrepo extends JpaRepository<Commentt, Integer>{

}
