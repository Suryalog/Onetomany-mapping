package com.relation.Relations.Repo;

import java.util.ArrayList;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.relation.Relations.Model.Commentt;
import com.relation.Relations.Model.Postt;

@Repository
public interface Posttrepo extends JpaRepository<Postt, Integer>{

	
	Postt findById(int id);
	//ArrayList<Commentt> findByCommentt(int id);

	
}
