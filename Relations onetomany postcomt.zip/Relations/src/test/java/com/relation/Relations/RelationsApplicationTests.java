package com.relation.Relations;

import org.glassfish.jaxb.runtime.v2.schemagen.xmlschema.List;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import com.relation.Relations.Model.Commentt;
import com.relation.Relations.Model.Postt;
//import com.relation.Relations.Repo.Postrepo;

import jakarta.transaction.Transactional;

import java.util.ArrayList;
import java.util.Set;

@SpringBootTest
class RelationsApplicationTests {

//	@Autowired
//	Postrepo repo;
	@Test
	void contextLoads() {
	}


//	@Test
//	public void cus() {
////		Postt p=new Postt();
////		p.setName("john");
////		List<Commentt> li=new ArrayList<>();
////		Commentt c1=new Commentt();
////		c1.setText("super");
////		li.add(c1);
////		c1.setPost(p);
////		Commentt c2=new Commentt();
////		c2.setText("weird");
////		c2.setPost(p);
////		
////		p.setComment(li);
////		
////		repo.save(p);
//		
//		Postt p=new Postt();
//		p.setName("babu");
//		
//		Commentt c=new Commentt();
//		c.setText("looking bad");
//		
//	
//		
//		
//		Commentt c1=new Commentt();
//		c1.setText("normal");
//		
//		p.add(c);
//		p.add(c1);
//	
//	
//		
//	    repo.save(p);
//		
//	}
//	
//	@Test
//	@Transactional
//	public void qwer() {
//		
//		Postt p = repo.findById(302);
//		
//		System.out.println(p.getName());
//
//		Set<Commentt> li = p.getComment();
//		for(Commentt e:li) {
//			System.out.println(e.getText());
//		}
////		
//		
//		
//	}
}
