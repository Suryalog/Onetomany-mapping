package com.hello.mapping.Entity;

import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;

import jakarta.annotation.Generated;
import jakarta.persistence.CascadeType;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.OneToMany;
@Entity
public class Prescription{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int presid;
	private String username;
	
	@OneToMany(mappedBy="prescription",cascade = CascadeType.ALL)
	@JsonIgnore
	private List<Tablet> tablet;
	
	public int getPresid() {
		return presid;
	}
	public void setPresid(int presid) {
		this.presid = presid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public List<Tablet> getTablet() {
		return tablet;
	}
	public void setTablet(List<Tablet> tablet) {
		this.tablet = tablet;
	}
	
	
	
	
}