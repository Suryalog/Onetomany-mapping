package com.hello.mapping.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hello.mapping.Entity.Prescription;
import com.hello.mapping.Entity.Tablet;
import com.hello.mapping.repository.Presrepository;
import com.hello.mapping.repository.Tabletrepository;

@Service
public class Presservice {

	@Autowired
	Presrepository repo;

	@Autowired
	Tabletrepository trepo;
	public String presdetails(Prescription pres) {
		repo.save(pres);
		return "saved";
	}

	public String add1(Tablet tab) {
		trepo.save(tab);
		return "tab saved";
	}

	public List<Tablet> tname(int a) {
		Prescription li=repo.findBypresid(a);
		List<Tablet>l=li.getTablet();
        List<String> ans=new ArrayList<>();
	    for(Tablet e:l) {
	    	ans.add(e.getTabletname());
	    }
	    System.out.println(ans);
	    
	    return l;
	    
	}
	
}
