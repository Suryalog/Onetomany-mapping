package com.hello.mapping.Exception;

public class UsernameNotFoundException extends Exception {

	public UsernameNotFoundException(String msg) {
		// TODO Auto-generated constructor stub
		super(msg);
	}
}
