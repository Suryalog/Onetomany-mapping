package com.hello.mapping.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.hello.mapping.Entity.Prescription;
import com.hello.mapping.Entity.Tablet;
import com.hello.mapping.service.Presservice;
import com.hello.mapping.service.Tablservice;

@RestController
public class Prescontroller {

	@Autowired
	Presservice ser;
	
	@Autowired
	Tablservice tablservice;
	@PostMapping("/add")
	public String presdetails(@RequestBody Prescription pres) {
		return ser.presdetails(pres);
	}
	
	@PostMapping("/tabadd/{presid}")
	public String add1(@RequestBody Tablet tab,@PathVariable int presid) {
		return tablservice.add1(tab,presid);
	}
	
	@GetMapping("/ge/{presid}")
	public List<Tablet> tname(@PathVariable int presid){
		System.out.println("helo");
		return ser.tname(presid);
	}
	
	
	
}
