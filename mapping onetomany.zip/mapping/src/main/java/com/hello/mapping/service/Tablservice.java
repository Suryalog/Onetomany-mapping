package com.hello.mapping.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.hello.mapping.Entity.Prescription;
import com.hello.mapping.Entity.Tablet;
import com.hello.mapping.Exception.UsernameNotFoundException;
import com.hello.mapping.repository.Presrepository;
import com.hello.mapping.repository.Tabletrepository;

@Service
public class Tablservice {
	
	@Autowired
	Tabletrepository repo;
	
	@Autowired
	Presrepository prepo;
	
	public String add1(Tablet tab,int presid) {
//		Prescription pres= prepo.findByPresid(presid);
//		if(pres == null)new UsernameNotFoundException("user not found");
////		Tablet tabSave = new Tablet();
////		
////		tabSave.setTabletname(tab.getTabletname());
////		tabSave.setPrescription(presid);
//		
//		tab.setPrescription(pres);
//		System.out.println(tab.getTabletname());
//		 repo.save(tab);
//		 return "Tablets saved";
		
		//Tablet tablet=new Tablet();
		Prescription pres= prepo.findByPresid(presid);
		tab.setPrescription(pres);
		repo.save(tab);
		return "tablet saved";
		
	}
	
}
