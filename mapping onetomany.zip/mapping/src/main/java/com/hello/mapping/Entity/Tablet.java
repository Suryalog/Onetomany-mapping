package com.hello.mapping.Entity;

import org.hibernate.annotations.ManyToAny;

import jakarta.annotation.Generated;
import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.JoinColumn;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.criteria.Join;

@Entity
public class Tablet{
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int tabletid;
	private String tabletname;
	@ManyToOne
	@JoinColumn(name="pres_id")
	private Prescription prescription;
	
	public int getTabletid() {
		return tabletid;
	}
	public void setTabletid(int tabletid) {
		this.tabletid = tabletid;
	}
	public String getTabletname() {
		return tabletname;
	}
	public void setTabletname(String tabletname) {
		this.tabletname = tabletname;
	}
	public Prescription getPrescription() {
		return prescription;
	}
	public void setPrescription(Prescription prescription) {
		this.prescription = prescription;
	}

	
	
}