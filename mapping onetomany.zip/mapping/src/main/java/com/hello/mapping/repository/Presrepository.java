package com.hello.mapping.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.hello.mapping.Entity.Prescription;

@Repository
public interface Presrepository extends JpaRepository<Prescription, Integer>{
 public Prescription findByPresid(int a);
 @Query("select p from Prescription p where p.presid=:b")
 public Prescription findBypresid(int b);
	
}
