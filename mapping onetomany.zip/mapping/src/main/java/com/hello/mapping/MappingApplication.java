package com.hello.mapping;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


import jakarta.persistence.Table;
import jakarta.transaction.Transactional;

@SpringBootApplication
public class MappingApplication{

	public static void main(String[] args) {
		SpringApplication.run(MappingApplication.class, args);
	}
	
	


}
